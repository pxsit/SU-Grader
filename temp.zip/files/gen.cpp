#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

const unsigned long long MAX = 18'000'000'000'000'000'000ULL;
const unsigned long long SAFE_MAX = 9'223'372'036'854'775'807ULL;

unsigned long long rul(unsigned long long l, unsigned long long r) {
    unsigned long long range = r - l + 1, limit = ULLONG_MAX - (ULLONG_MAX % range), x;
    do {
        x = (rnd.next(0u, UINT_MAX) << 32) | rnd.next(0u, UINT_MAX);
    } while (x >= limit);
    return l + (x % range);
}

int32_t main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int sub = atoi(argv[1]);
    unsigned long long n;
    bool maxconst = false;

    switch (sub) {
        case 1: n = 1000ULL; break;
        case 2: n = 1'000'000ULL; break;
        case 3: n = MAX; break;
        case 4: n = MAX; maxconst = true; break;
    }

    if (maxconst) {
        cout << MAX << ' ' << MAX << ' ' << MAX << '\n';
        return 0;
    }

    cout << rul(1, MAX) << ' ' << rul(1, n) << ' ' << rul(1, MAX) << '\n';
    return 0;
}
