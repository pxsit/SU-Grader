#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
const unsigned long long MAX_VAL = 18'000'000'000'000'000'000ULL;
int main(int argc,char*argv[]) {
    registerValidation(argc,argv);
    unsigned long long a = inf.readUnsignedLong(1, MAX_VAL, "a");
    inf.readSpace();
    unsigned long long n = inf.readUnsignedLong(1, MAX_VAL, "n");
    inf.readSpace();
    unsigned long long d = inf.readUnsignedLong(1, MAX_VAL, "d");
    inf.readEoln();
    inf.readEof();
    return 0;
}
