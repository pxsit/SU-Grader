#include <bits/stdc++.h>
using namespace std;

#define ull unsigned long long
#define m 1000000007

ull modmulti(ull a, ull b, ull mod) {
    ull result = 0;
    a %= mod;
    while (b > 0) {
        if (b & 1)
            result = (result + a) % mod;
        a = (2 * a) % mod;
        b >>= 1;
    }
    return result;
}

ull modpow(ull base, ull exp, ull mod) {
    ull result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp & 1)
            result = modmulti(result, base, mod);
        base = modmulti(base, base, mod);
        exp >>= 1;
    }
    return result;
}

ull slove(ull a, ull n, ull d, ull mod) {
    ull term1 = modmulti(2, a, mod);
    ull term2 = modmulti(n - 1, d, mod);
    ull sum_inner = (term1 + term2) % mod;
    ull numerator = modmulti(n, sum_inner, mod);
    ull inverse_two = modpow(2, mod - 2, mod);

    return modmulti(numerator, inverse_two, mod);
}

int main() {
    ull a, n, d;
    cin >> a >> n >> d;

    cout << slove(a, n, d, m) << endl;

    return 0;
}